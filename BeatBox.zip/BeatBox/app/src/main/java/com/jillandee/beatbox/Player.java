package com.jillandee.beatbox;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;

public class Player extends AppCompatActivity {
    Bundle songExtraData;
    ArrayList<File> songFileList;
    SeekBar mSeekbar;
    TextView mSongTitle;
    TextView currentTime;
    TextView totalTime;
    ImageView play;
    ImageView prev;
    ImageView next;

    static MediaPlayer mMediaPlayer;

    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        mSeekbar = findViewById(R.id.musicSeekbar);
        mSongTitle = findViewById(R.id.songTitle);
        play = findViewById(R.id.play);
        prev = findViewById(R.id.prev);
        next = findViewById(R.id.next);
        currentTime = findViewById(R.id.currentTime);
        totalTime = findViewById(R.id.totalTime);

        if(mMediaPlayer != null){
            mMediaPlayer.stop();
        }

        Intent songData = getIntent();
        songExtraData = songData.getExtras();

        songFileList = (ArrayList)songExtraData.getParcelableArrayList("songList");
        position = songExtraData.getInt("position", 0);

        initMusicPlayer(position);

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                play();
            }
        });

        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (position < songFileList.size() - 1) {

                    position ++;

                }else{

                    position = 0;
                }

                initMusicPlayer(position);
            }
        });

        prev.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (position <= 0) {

                    position = songFileList.size() - 1;

                }else{

                    position --;
                }

                initMusicPlayer(position);
            }
        });
    }

    private void initMusicPlayer(final int position){
        if(mMediaPlayer != null && mMediaPlayer.isPlaying()){
            mMediaPlayer.stop();
        }
        String name = songFileList.get(position).getName();
        mSongTitle.setText(name);

        Uri songResourceUri = Uri.parse(songFileList.get(position).toString());

        mMediaPlayer = MediaPlayer.create(getApplicationContext(), songResourceUri);
        mMediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mSeekbar.setMax(mMediaPlayer.getDuration());

                String totTime = createTimerLabel(mMediaPlayer.getDuration());
                totalTime.setText(totTime);

                mMediaPlayer.start();

                play.setImageResource(R.drawable.ic_pause);
            }
        });

        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                //play.setImageResource(R.drawable.ic_play);

                int currentSongPosition = position;

                if (currentSongPosition < songFileList.size() - 1) {

                    currentSongPosition ++;

                }else{

                    currentSongPosition = 0;
                }

                initMusicPlayer(currentSongPosition);
            }
        });

        mSeekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(fromUser){
                    mMediaPlayer.seekTo(progress);
                    mSeekbar.setProgress(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(mMediaPlayer != null){
                    try {
                        if(mMediaPlayer.isPlaying()){
                            Message message = new Message();
                            message.what = mMediaPlayer.getCurrentPosition();
                            handler.sendMessage(message);
                            Thread.sleep(1000);
                        }
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        }).start();

    }

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            currentTime.setText(createTimerLabel(msg.what));
            mSeekbar.setProgress(msg.what);
        }
    };

    private void play(){
        if (mMediaPlayer != null && mMediaPlayer.isPlaying()){
            mMediaPlayer.pause();
            play.setImageResource(R.drawable.ic_play);
        }else{
            mMediaPlayer.start();
            play.setImageResource(R.drawable.ic_pause);
        }
    }

    public String createTimerLabel(int duration){
        String timerLabel = "";
        int min = duration / 1000 / 60;
        int sec = duration / 1000 % 60;

        timerLabel += min + ":";

        if(sec < 10) timerLabel += "0";
        timerLabel += sec;

        return timerLabel;
    }
}
